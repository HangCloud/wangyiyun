<template>
  <div class="main-page">
    <Content class="main-page-content" />
  </div>
</template>

<script>
import Content from "@/components/RankingPage/Index";
export default {
  components: {
    Content,
  }
};
</script>

<style scoped>
.main-page {
  width: 100%;
  background-color: #f5f5f5;
}
</style>