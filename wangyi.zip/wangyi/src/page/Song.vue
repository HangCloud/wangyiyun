<template>
    <div class="page-song">
        <one-song />
    </div>
</template>

<script>
import OneSong from '@/components/Song/Index';

export default {
    components:{
        OneSong,
    }
}
</script>

<style lang="scss" scoped>
    .page-song{
        background-color: #f5f5f5;
    }
</style>