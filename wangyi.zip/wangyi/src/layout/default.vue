<template>
  <div class="main-page">
    <Header class="main-page-header" />
    <router-view />
    <Footer class="main-page-footer" />
  </div>
</template>

<script>
import Header from "@/components/Index/Header/Index";
import Footer from "@/components/Index/Footer/Index";
export default {
  components: {
    Header,
    Footer
  }
};
</script>

<style scoped>
.main-page {
  width: 100%;
  height: 100%;
}
.main-page .main-page-header {
  height: 105px;
  width: 100%;
  background-color: #242424;
}
</style>