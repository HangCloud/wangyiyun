import Vue from 'vue'
import Router from 'vue-router'

import ErrorPage from '@/layout/error.vue';
import defaultPage from '@/layout/default.vue'

import IndexPage from '@/page/Index.vue'
import RankingPage from '@/page/RankingPage'
import SongPage from '@/page/Song.vue'


Vue.use(Router)

export default new Router({
  mode: 'history',       //指定为历史模式
  routes: [
    {
      path: '/',
      name: 'default',
      component: defaultPage,
      redirect: 'Index',
      children: [
        {
          path: '/Index',
          name: 'Index',
          component: IndexPage,
        },
        {
          path: '/RankingPage',
          name: 'RankingPage',
          component: RankingPage
        },
        {
          path: '/Song',
          name: 'Song',
          component: SongPage
        }
      ]
    }, {
      path: '*',
      name: '*',
      component: ErrorPage,
    }],

})
