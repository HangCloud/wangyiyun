import axios from 'axios'
axios.defaults.baseURL='http://192.168.3.6:10086';
axios.interceptors.request.use(function (config) {
    config.params = {
        ...config.parmas,
    }
    return config;
}, function (error) {
    return Promise.reject(error);
});

export default axios;