


Top.vue是一个公共的回到顶部的组件


Index：发现音乐=》推荐

RankingPage：发现音乐=》排行榜