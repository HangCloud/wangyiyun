<template>
  <div class="nav-bar">
    <ul>
      <!-- item.url -->
      <li v-for="item in navList" :key="item.id" @click="handleClick(item.id)">
          <router-link :to="{path:item.url}" :class="[item.active?'active':'']">
                {{ item.name }}
                </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["navList"],
  methods:{
    handleClick:function(id){
      this.$emit("switch",id);
    }
  }
};
</script>

<style scoped>
.nav-bar {
  width: 100%;
  height: 35px;
  background-color: #c20c0c;
}
ul {
  padding-left: 302px;
  height: 35px;
  width: 600px;
}
ul li {
  float: left;
  text-align: center;
  padding: 0 20px;
}
ul li a {
  text-decoration: none;
  color: #fff;
  line-height: 35px;
      padding: 5px 12px;
}
ul li .active{
    background-color: #9B0909;
    border-radius: 20px;
}
ul li a:hover{
    background-color: #9B0909;
    padding: 5px 12px;
    border-radius: 20px;
}
</style>