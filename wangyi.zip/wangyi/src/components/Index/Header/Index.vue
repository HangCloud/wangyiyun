<template>
  <div>
    <div class="header-content">
      <img src="../../../assets/logo.jpg" alt="网易云音乐" />
      <ul>
        <li v-for="item in menuList" :key="item.id" :class="active">
          <a :href="item.url" :class="[item.active?'active':'']">
            <em>{{ item.name }}</em>
          </a>
          <div class="triangle" :class="{active:item.active}"></div>
        </li>
      </ul>
      <el-input
        class="search"
        placeholder="音乐/视频/电台/用户"
        prefix-icon="el-icon-search"
        v-model="search"
      />
      <span class="creation">
        <a href="baidu.com" class>创作者中心</a>
      </span>
      <span class="login">登录</span>
    </div>

    <Nav :navList="typeList" @switch="receive" />
  </div>
</template>

<script>
import api from '@/api/index.js'
import Nav from "./Nav.vue";

export default {
  data() {
    return {
      menuList: [],
      active: "btn-nav",
      logoUrl: "./logo.jpg",
      search: "",
      typeList: [
        { id: 101, name: "推荐", url: "/Index", active: true },
        { id: 102, name: "排行榜", url: "/RankingPage", active: false },
        { id: 103, name: "歌单", url: "/Song", active: false },
        { id: 104, name: "主播电台", url: "baidu.com", active: false },
        { id: 105, name: "歌手", url: "baidu.com", active: false },
        { id: 106, name: "新碟上架", url: "baidu.com", active: false }
      ]
    };
  },
  components: {
    Nav
  },
  created() {
    api.getNavList().then(res=>{
        this.menuList = res.data;
    })
  },
  methods:{
    //子组件回调处理选中状态
    receive:function(id){
      let tempList = this.typeList.map(item => {
        if(item.id==id){
          item.active=true;
        }else{
          item.active=false;
        }
        return item;
      });
    }
  }
};
</script>

<style scoped>
* {
  text-decoration: none;
  color: #fff;
}
.header-content {
  height: 70px;
  width: 1100px;
  font-size: 14px;
  margin: 0 auto;
}
.header-content ul li {
  float: left;
  position: relative;
}
.header-content ul li .triangle.active {
  position: absolute;
  border:10px solid #666;
  border-top-color: transparent;
  border-bottom-color: #C20C0C;
  border-left-color: transparent;
  border-right-color: transparent;
  left:calc(50% - 10px);
  bottom:0px;
}
.btn-nav a {
  color: #ccc;
  font-size: 14px;
  text-decoration: none;
  padding: 0 19px;
  height: 70px;
  line-height: 70px;
  text-align: center;
  display: inline-block;
}
.btn-nav .active {
  background-color: #000;
}
img {
  float: left;
}
.btn-nav:hover {
  background-color: #000;
  color: #fff;
}
ul {
  float: left;
  padding-left: 16px;
}
.btn-nav em {
  font-size: 14px;
}

.search {
  width: 158px;
  line-height: 70px;
  margin-left: 93px;
}

.search >>> .el-input__inner {
  border-radius: 20px;
  font-size: 12px;
  color: #333;
  height: 32px;
}
.creation {
  box-sizing: border-box;
  margin-left: 5px;
  width: 92px;
  height: 32px;
  border: 1px solid #4f4f4f;
  border-radius: 20px;
  display: inline-block;
  line-height: 32px;
  text-align: center;
  font-size: 12px;
}
.creation a {
  color: #ccc;
  text-decoration: none;
}
.login {
  margin-left: 8px;
  color: #787878;
}
</style>