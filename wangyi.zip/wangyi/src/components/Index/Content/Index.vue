<template>
  <div>
    
    <Carousel />
    <div class="main-list">
     <Left />
      <div class="musicList">
        <div class="recommend">
          <Navigation :recommendeds="recommendeds" class="nav-recommend" />
        </div>
        <div class>
          <MusicList :musicList="musicList" />
        </div>
      </div>

      <div class="new-film">
        <div class="recommend">
          <Navigation :recommendeds="newFilm" class="nav-recommend" />
        </div>
      </div>
      <Slideshow :imgObjs="imgObjs" />

      <div class="new-film">
        <div class="recommend">
          <Navigation :recommendeds="ranking" class="nav-recommend" />
        </div>
      </div>
      <Ranking />
    </div>
  </div>
</template>

<script>
import Carousel from "./Carousel/Carousel.vue";
import Navigation from "./Navigation/Navigation.vue";
import MusicList from "./Navigation/MusicList.vue";
import Slideshow from "./Carousel/Slideshow.vue";
import Ranking from "./Carousel/Ranking.vue";
import Left from "./Deputy/Left.vue";

export default {
  data() {
    return {
      recommendeds: {
        title: "热门推荐",
        navList: [
          { id: 1001, name: "华语", url: "baidu.com" },
          { id: 1002, name: "流行", url: "baidu.com" },
          { id: 1003, name: "摇滚", url: "baidu.com" },
          { id: 1004, name: "民谣", url: "baidu.com" },
          { id: 1005, name: "电子", url: "baidu.com" }
        ]
      },
      musicList: [
        {
          id: 101,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: true,
          url: "baidu.com"
        },
        {
          id: 102,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: false,
          url: "baidu.com"
        },
        {
          id: 103,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: true,
          url: "baidu.com"
        },
        {
          id: 104,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: false,
          url: "baidu.com"
        },
        {
          id: 105,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: true,
          url: "baidu.com"
        },
        {
          id: 106,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: false,
          url: "baidu.com"
        },
        {
          id: 107,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: true,
          url: "baidu.com"
        },
        {
          id: 108,
          number: 1231,
          msg: "入耳即融，那些甜到心底的温柔男声",
          imgUrl:
            "http://p2.music.126.net/IASE1JJvhHIEX1feeM_D3Q==/109951164461413561.jpg?param=140y140",
          dj: false,
          url: "baidu.com"
        }
      ],
      newFilm: {
        title: "新碟上架",
        navList: []
      },
      imgObjs: [
        [
          {
            id: 101,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "A",
            author: "群星"
          },
          {
            id: 102,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "B",
            author: "群星"
          },
          {
            id: 103,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "C",
            author: "群星"
          },
          {
            id: 104,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "D",
            author: "王菲"
          },
          {
            id: 105,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "E",
            author: "群星"
          }
        ],
        [
          {
            id: 106,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "AAA",
            author: "群星"
          },
          {
            id: 107,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "BBB",
            author: "林俊杰"
          },
          {
            id: 108,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "CCC",
            author: "群星"
          },
          {
            id: 109,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "DDD",
            author: "群星"
          },
          {
            id: 110,
            imgSrc:
              "http://p4.music.126.net/L12rDtpQn6zsGXzVdEdp5Q==/109951164429099932.jpg?param=100y100",
            name: "EEE",
            author: "Taylor Swift"
          }
        ]
      ],
      ranking: {
        title: "榜单",
        navList: []
      }
    };
  },
  components: {
    Carousel,
    Navigation,
    MusicList,
    Slideshow,
    Ranking,
    Left
  }
};
</script>
<style>
.main-list {
  width: 982px;
  margin: 0 auto;
  background-color: #fff;
  position: relative;
}
.musicList {
  display: inline-block;
}
.musicList .recommend {
  width: 690px;
}
.recommend .nav-recommend {
  margin: 15px 0px 0px 20px;
}
</style>