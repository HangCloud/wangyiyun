<template>
    <div>
      <el-carousel :interval="5000" arrow="always" trigger="click">
        <el-carousel-item v-for="item in imgSrcs" :key="item.id">
          <div class="lb-back" :style="{backgroundImage: 'url(' + item.img_back + ')'}">
            <div class="wrap">
              <img :src="item.img" alt />
            </div>
          </div>
        </el-carousel-item>
      </el-carousel>
      <div class="download">
        <img src="../../../../assets/Imgs/download.png" alt />
        <a class="a-download" href="#"></a>
        <span class="msg">PC 安卓 iPhone WP iPad Mac 六大客户端</span>
      </div>
    </div>
</template>

<script>
import api from '@/api/index.js'
export default {
    data(){
      return{
        imgSrcs:[]
      }
    },
    created(){
       api.getSlideshowList().then(res=>{
        this.imgSrcs = res.data;
    })
    }
}
</script>

<style>
.el-carousel__container{
    height: 285px;
}
.el-carousel__arrow {
  background: none;
  width: 35px;
  height: 60px;
  border-radius: 0%;
}
.el-carousel__arrow:hover {
  width: 35px;
  height: 60px;
  border-radius: 0%;
}
.el-carousel__arrow--left {
  left: 110px;
  font-size: 49px;
  text-align: center;
}
.el-carousel__arrow i {
  margin-left: -5px;
}
.el-carousel__arrow--right {
  right: 110px;
  font-size: 48px;
  text-align: center;
}
.el-carousel__indicators--horizontal {
  left: 40%;
}
.el-carousel__indicators--horizontal .is-active button {
  background-color: #c20c0c;
}
.el-carousel__indicators .el-carousel__indicator:hover button {
  background-color: #c20c0c;
}
.el-carousel__button {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  margin-bottom: 20px;
  margin-left: 10px;
}

.lb-back {
  width: 100%;
  height: 285px;
  background-size: 6000px;
  background-position: center center;
}
.lb-back .wrap {
  width: 982px;
  height: 285px;
  margin: 0 auto;
  position: relative;
}
.lb-back .wrap img {
  height: 285px;
}

.download {
  float: right;
  height: 285px;
  width: 254px;
  overflow: hidden;
  position: absolute;
  top: 105px;
  right: 183px;
  z-index: 9;
}
.download .a-download {
  width: 215px;
  height: 55px;
  position: absolute;
  left: 20px;
  bottom: 45px;
  opacity: 0;
  background-color: #fff;
}
.download .a-download:hover {
  opacity: 0.1;
}
.download .msg {
  width: 230px;
  position: absolute;
  left: 16px;
  bottom: 15px;
  color: #8d8d8d;
}
</style>