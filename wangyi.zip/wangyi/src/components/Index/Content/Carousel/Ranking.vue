<template>
    <div class="phb">
        <ranking-list :data="dataList[0]" class="ph-lb"/>
        <ranking-list :data="dataList[1]" class="ph-lb"/>
        <ranking-list :data="dataList[2]" class="ph-lb"/>
    </div>
</template>

<script>
import RankingList from './RankingList.vue';
export default {
    components:{
        RankingList,
    },
    data(){
        return {
            dataList:[
                {id:1,imgSrc:"http://p3.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=100y100",title:"云音乐飙升榜",list:[
                    {id:101,name:"Lover (Remix)"},
                    {id:102,name:"悬溺"},
                    {id:103,name:"Señorita"},
                    {id:104,name:"我在原地等你"},
                    {id:105,name:"少女"},
                    {id:106,name:"怪我太爱你"},
                    {id:107,name:"与火星的孩子对话"},
                    {id:108,name:"大田後生仔"},
                    {id:109,name:"唱不下去"},
                    {id:110,name:"那女孩对我说（女生正式版）"},
                ]},
                {id:2,imgSrc:"http://p4.music.126.net/N2HO5xfYEqyQ8q6oxCw8IQ==/18713687906568048.jpg?param=100y100",title:"云音乐新歌榜",list:[
                    {id:201,name:"你的答案"},
                    {id:202,name:"大田後生仔"},
                    {id:203,name:"连名带姓"},
                    {id:204,name:"Lover (Remix)"},
                    {id:205,name:"与火星的孩子对话"},
                    {id:206,name:"绿洲"},
                    {id:207,name:"我可以"},
                    {id:208,name:"初秋和你"},
                    {id:209,name:"拾忆"},
                    {id:210,name:"Love poem"},
                ]},
                {id:3,imgSrc:" http://p4.music.126.net/sBzD11nforcuh1jdLSgX7g==/18740076185638788.jpg?param=100y100",title:"网易原创歌曲榜",list:[
                    {id:301,name:"初秋和你"},
                    {id:302,name:"给你"},
                    {id:303,name:"一拍两散"},
                    {id:304,name:"一个人的狂欢"},
                    {id:305,name:"MAYBEDEAD"},
                    {id:306,name:"砰砰"},
                    {id:307,name:"来客"},
                    {id:308,name:"世纪大爆炸"},
                    {id:309,name:"距离你的泪滴只有六厘米"},
                    {id:310,name:"梦"},
                ]}
            ]
        }
    }
}
</script>

<style>
.phb{
    width:690px;
    height: 472px;
    margin: 15px 0px 0px 20px;
    padding-bottom: 40px;
}
    .ph-lb{
        width:230px;
        height: 472px;
        background-color: #f4f4f4;
        float: left;
    }
</style>