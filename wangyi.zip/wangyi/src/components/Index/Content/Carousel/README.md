

**【Ranking.vue】这个组件是首页的榜单部分，引用了RankingList.vue这个组件**
**【RankingList.vue】这个组件是首页的榜单中的一列**
**【Slideshow.vue】这个组件是首页中的新碟上架的部分，主要处理的轮播效果**
**【Carousel.vue】这个组件是首页的轮播图部分**

