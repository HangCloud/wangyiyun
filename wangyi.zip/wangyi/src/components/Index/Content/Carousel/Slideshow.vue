<template>
  <div class="container b-container">
    <span class="left">
      <i v-on:click="left" class="iconfont icon-leftarrow"></i>
    </span>
    <span class="right">
      <i v-on:click="right" class="iconfont icon-zuoyoujiantou-copy-copy-copy1"></i>
    </span>

    <div class="x-container">
      <ul class="first" :style="{'left':scale[0]+'px'}">
        <div class="zjbj">
          <li v-for="(item,index) in imgObjs[1]" :key="item.id+index">
            <a href="#" :title="item.name" class="imgbg">
              <img :src="item.imgSrc" alt />
              <i class="iconfont icon-bofang2 play"></i>
            </a>
            <p>
              <a class="name" href="#" :title="item.name">{{ item.name }}</a>
            </p>
            <span>{{ item.author }}</span>
          </li>
        </div>
      </ul>

      <ul :style="{'left':scale[1]+'px'}">
        <div class="zjbj">
          <li v-for="item in imgObjs[0]" :key="item.id">
            <a href="#" :title="item.name" class="imgbg">
              <img :src="item.imgSrc" alt />
              <i class="iconfont icon-bofang2 play"></i>
            </a>
            <p>
              <a class="name" href="#" :title="item.name">{{ item.name }}</a>
            </p>
            <span>{{ item.author }}</span>
          </li>
        </div>
      </ul>
      <ul :style="{'left':scale[2]+'px'}">
        <div class="zjbj">
          <li v-for="item in imgObjs[1]" :key="item.id">
            <a href="#" :title="item.name" class="imgbg">
              <img :src="item.imgSrc" alt />
              <i class="iconfont icon-bofang2 play"></i>
            </a>
            <p>
              <a class="name" href="#" :title="item.name">{{ item.name }}</a>
            </p>
            <span>{{ item.author }}</span>
          </li>
        </div>
      </ul>

      <ul :style="{'left':scale[3]+'px'}">
        <div class="zjbj">
          <li v-for="(item,index) in imgObjs[0]" :key="index">
            <a href="#" :title="item.name" class="imgbg">
              <img :src="item.imgSrc" alt />
              <i class="iconfont icon-bofang2 play"></i>
            </a>
            <p>
              <a class="name" href="#" :title="item.name">{{ item.name }}</a>
            </p>
            <span>{{ item.author }}</span>
          </li>
        </div>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  props: ["imgObjs"],
  data() {
    return {
      number: 0, //当前现实的Ul编号，默认为第二个
      scale: [-645, 0, 645, 645] //4个ul的marginleft值，用于设置轮播
    };
  },
  watch: {},
  methods: {
    //左边箭头
    left: function() {
      let time = 16; //每隔14毫秒移动一次
      let step = 5; //每次移动的距离
      let timer = null;
      this.number--;
      // 如果到了左边边界(从0切到-1)
      if (this.number < 0) {
        clearInterval(timer);
        timer = setInterval(() => {
          this.scale[0] = step + this.scale[0];
          this.scale[1] = step + this.scale[1];
          this.$forceUpdate();
          if (this.scale[0] * -1 < 0) {
            this.scale[2] = 0;
            this.scale[0] = -645;
            this.scale[1] = -645;
            this.number = 1;
            clearInterval(timer);
          }
        }, time);
      } else {
        //从1切到0
        clearInterval(timer);
        timer = setInterval(() => {
          this.scale[1] = step + this.scale[1];
          this.scale[2] = step + this.scale[2];
          this.$forceUpdate();
          if (this.scale[1] > 0) {
            this.scale[1] = 0;
            this.scale[2] = 645;
            this.number = 0;
            clearInterval(timer);
          }
        }, time);
      }
    },
    //右边箭头
    right: function() {
      let time = 14; //每隔14毫秒移动一次
      let step = 5; //每次移动的距离
      let timer = null;
      this.number++;
      // 如果到了右边边界(从1切到2)
      if (this.number > 1) {
        clearInterval(timer);
        timer = setInterval(() => {
          this.scale[2] = this.scale[2] - step;
          this.scale[3] = this.scale[3] - step;
          this.$forceUpdate();
          if (this.scale[3] < 0) {
            this.scale[1] = 0;
            this.scale[2] = 645;
            this.scale[3] = 645;
            this.number = 0;
            clearInterval(timer);
          }
        }, time);
      } else {
        //从1切到0
        clearInterval(timer);
        timer = setInterval(() => {
          this.scale[1] = this.scale[1] - step;
          this.scale[2] = this.scale[2] - step;
          this.$forceUpdate();
          if (this.scale[2] < 0) {
            this.scale[1] = -645;
            this.scale[2] = 0;
            this.number = 1;
            clearInterval(timer);
          }
        }, time);
      }
    }
  }
};
</script>

<style>
.b-container {
  width: 690px;
  position: relative;
  zoom: 1;
  height: 186px;
  margin: 20px 16px 50px 20px;
  border: 1px solid #d3d3d3;
  overflow: hidden;
  background: #f5f5f5;
}
.b-container .x-container {
  width: 645px;
  height: 186px;
  overflow: hidden;
  position: relative;
  margin-left: 15px;
}
.b-container .left,
.right {
  line-height: 150px;
  position: absolute;
  color: #666;
}
.b-container .left {
  left: 5px;
}
.b-container .left i {
  width: 10px;
  height: 10px;
}
.b-container .left i:hover {
  cursor: pointer;
}
.b-container .right {
  right: 10px;
}
.b-container .right i {
  width: 10px;
  height: 10px;
}
.b-container .right i:hover {
  cursor: pointer;
}
.b-container ul {
  margin: 28px 0 0 0;
  /* transition: none 0s ease 0s; */
  width: 645px;
  position: absolute;
}

.b-container ul li {
  float: left;
  width: 118px;
  height: 150px;
  margin-left: 11px;
}
.b-container ul li .imgbg {
  background-color: crimson;
  display: block;
  background-image: url("../../../../assets/Imgs/zjbj.jpg");
  box-shadow: 0px 20px 20px -15px #888;
  position: relative;
}
.b-container ul li .imgbg:hover .play {
  display: inline-block;
}
.b-container ul li .imgbg .play {
  position: absolute;
  bottom: 3px;
  color: #666;
  opacity: 0.8;
  right: 26px;
  font-size: 22px;
  display: none;
}
.b-container ul li .imgbg .play:hover {
  color: #333;
}
.b-container ul li p {
  width: 105px;
  white-space: nowrap; /*内容超宽后禁止换行显示*/
  overflow: hidden; /*超出部分隐藏*/
  text-overflow: ellipsis; /*文字超出部分以省略号显示*/
  padding: 5px 0px;
}
.b-container ul li p a {
  color: #000;
}
.b-container ul li p a:hover {
  width: 100%;
  border-bottom: 1px solid #000;
  cursor: pointer;
}
.b-container ul li img {
  display: block;
}
.b-container ul li span {
  color: #666;
}
.b-container ul li span:hover {
  border-bottom: 1px solid #666;
  cursor: pointer;
}
</style>