<template>
  <div class="con-list">
    <dl>
      <dt class="top">
        <img :src="data.imgSrc" alt />
        <div class="tit">
          <a href="#">
            <h3>{{ data.title }}</h3>
          </a>
          <div class="icon">
            <i class="iconfont icon-bofang1"></i>
            <i class="iconfont icon-wenjiantianjia"></i>
          </div>
        </div>
      </dt>
      <dd>
        <ol>
          <li v-for="(item,index) in data.list" :key="index" class="d-list">
            <span class="no-top" :class="{'top3':index<3}">{{ index+1 }}</span>
            <a class="nm" href="#">{{ item.name }}</a>
            <div class="action">
              <i class="iconfont icon-bofang1"></i>
              <i class="iconfont icon-jia"></i>
              <i class="iconfont icon-wenjiantianjia"></i>
            </div>
          </li>
          <div class="more">
            <a href="#">查看全部&gt;</a>
          </div>
        </ol>
      </dd>
    </dl>
  </div>
</template>

<script>
export default {
  props: ["data"]
};
</script>

<style>
.con-list {
  position: relative;
  box-sizing: border-box;
  border-top: 0.5px solid #ccc;
  border-bottom: 0.5px solid #ccc;
}
.top {
  height: 100px;
  padding: 20px 0 0 19px;
  border-right: 0.5px solid #ccc;
}
.con-list:nth-of-type(1) .top {
  border-left: 0.5px solid #ccc;
}
.top img,
.tit {
  float: left;
  width: 80px;
}
.top .tit {
  margin: 6px 0 0 10px;
}
.top .tit a h3 {
  font-size: 14px;
  font-weight: bold;
  overflow: hidden;
  color: #000;
  width: 105px;
}
.top .tit a h3:hover {
  cursor: pointer;
  text-decoration: underline;
}

.top .tit .icon {
  padding-top: 10px;
  color: #b0b0b0;
  position: relative;
}
.top .tit .icon i:hover {
  color: #666;
  cursor: pointer;
}
.top .tit .icon .iconfont {
  font-size: 22px;
}
.con-list:nth-of-type(1) .d-list {
  border-left: 0.5px solid #ccc;
}
.d-list {
  width: 230px;
  height: 32px;
  float: right;
  font-size: 16px;
  border-right: 0.5px solid #ccc;
  box-sizing: border-box;
  position: relative;
}
.d-list .action {
  position: absolute;
  top: 8px;
  right: 10px;
  color: #999;
  font-weight: bold;
  position: absolute;
  display: none;
}
.d-list .action i:hover {
  color: #777;
}
.d-list .no-top {
  margin-left: 30px;
  line-height: 32px;
  width: 20px;
  height: 32px;
  display: inline-block;
  text-align: center;
}
.d-list .top3 {
  color: #c10d0c;
}
.d-list:hover .nm {
  text-decoration: underline;
  width: 90px;
}
.d-list:hover .action {
  display: inline-block;
  cursor: pointer;
}
.d-list .nm {
  font-size: 12px;
  color: #000;
  overflow: hidden;
  display: block;
  white-space: nowrap;
  text-overflow: ellipsis;
  margin-top: -23px;
  margin-left: 57px;
}
.d-list:nth-of-type(odd) {
  background-color: #e8e8e8;
}
.con-list:nth-of-type(1) .more {
  border-left: 0.5px solid #ccc;
}
ol .more {
  width: 230px;
  height: 32px;
  background-color: #e8e8e8;
  position: absolute;
  bottom: 0px;
  line-height: 32px;
  border-right: 0.5px solid #ccc;
  box-sizing: border-box;
}
ol .more a {
  padding-left: 155px;
  color: #000;
}
</style>