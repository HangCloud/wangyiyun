
**本文件夹主要负责的是首页上主要内容部分右侧的副页部分**

**【MinLogin.vue】副页小登录模块**
**【InSingerList.vue】入驻歌手列表**
**【InSinger.vue】单个入驻歌手**
**【Anchor.vue】单个热门主播**
**【AnchorList.vue】热门主播列表**

**【Left.vue】主页副页的和**