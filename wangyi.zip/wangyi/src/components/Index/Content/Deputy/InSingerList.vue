<template>
  <div class="in-singer">
    <div class="header">
      <span>入驻歌手</span>
      <a href="#">查看全部&gt;</a>
    </div>
    <div v-for="item in SingerData" :key="item.id">
      <InSinger :SingerMsg="item" />
    </div>
    <button class="apply">申请成为网易音乐人</button>
  </div>
</template>

<script>
import InSinger from "./InSinger.vue";

export default {
  components: {
    InSinger
  },
  data() {
    return {
      SingerData: [
        {
          id: 1,
          imgurl:
            "http://p1.music.126.net/p9U80ex1B1ciPFa125xV5A==/5931865232210340.jpg?param=62y62",
          name: "张惠美",
          describe: "台湾歌手张惠妹"
        },
        {
          id: 2,
          imgurl:
            "http://p1.music.126.net/p9U80ex1B1ciPFa125xV5A==/5931865232210340.jpg?param=62y62",
          name: "张惠美",
          describe: "台湾歌手张惠妹"
        },
        {
          id: 3,
          imgurl:
            "http://p1.music.126.net/p9U80ex1B1ciPFa125xV5A==/5931865232210340.jpg?param=62y62",
          name: "张惠美",
          describe: "台湾歌手张惠妹"
        },
        {
          id: 4,
          imgurl:
            "http://p1.music.126.net/p9U80ex1B1ciPFa125xV5A==/5931865232210340.jpg?param=62y62",
          name: "张惠美",
          describe: "台湾歌手张惠妹"
        },
        {
          id: 5,
          imgurl:
            "http://p1.music.126.net/p9U80ex1B1ciPFa125xV5A==/5931865232210340.jpg?param=62y62",
          name: "张惠美",
          describe: "台湾歌手张惠妹"
        }
      ]
    };
  }
};
</script>

<style scoped>
.in-singer {
  margin: 18px 0 14px 20px;
}
.in-singer .header {
  width: 210px;
  height: 24px;
  border-bottom: 1px solid #ccc;
}
.in-singer .header span {
  float: left;
  font-size: 12px;
  font-family: Arial, Helvetica, sans-serif;
}
.in-singer .header a {
  float: right;
}
.in-singer .apply {
  width: 210px;
  height: 30px;
  border-radius: 4px;
  color:#333;
  font-weight: bold;
  border: 1px solid #ccc;
  margin:15px auto;
  background: linear-gradient(#fff, #f1f1f1);
}
</style>