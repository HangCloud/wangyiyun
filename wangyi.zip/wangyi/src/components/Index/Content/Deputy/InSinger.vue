<template>
  <div class="singer">
    <img :src="SingerMsg.imgurl" alt />
    <div class="msg">
      <h3>{{ SingerMsg.name }}</h3>
      <span>{{ SingerMsg.describe }}</span>
    </div>
  </div>
</template>

<script>
export default {
  props: ["SingerMsg"]
};
</script>

<style scoped>
.singer {
  float: left;
  width: 210px;
  height: 62px;
  background: #fafafa;
  margin-top: 10px;
  border: 1px solid #e9e9e9;
}
.singer img {
  float: left;
}
.singer .msg {
  float: left;
  width: 133px;
  height: 60px;
  padding-left: 14px;
  border-left: none;
  margin-top: 8px;
}
.singer .msg h3 {
  font-size: 14px;
  color: #333;
  font-family: Arial, Helvetica, sans-serif;
  font-weight: bold;
}
.singer .msg span {
  margin-top: 10px;
  display: block;
}
</style>