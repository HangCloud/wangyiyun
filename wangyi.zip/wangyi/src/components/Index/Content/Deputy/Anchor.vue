<template>
  <div class="a-wrap">
    <img :src="AnchorData.imgUrl" alt />
    <div class="msg">
      <h3>
        {{ AnchorData.name }}
        <i class="i iconfont icon-dakazhuanlan"></i>
      </h3>
      <span :title="AnchorData.describe">{{ AnchorData.describe }}</span>
    </div>
  </div>
</template>

<script>
export default {
  props: ["AnchorData"]
};
</script>

<style scoped>
.a-wrap {
  width: 210px;
  height: 40px;
  float: left;
  margin-top: 12px;
}

.a-wrap img {
  float: left;
}
.a-wrap .msg {
  float: left;
  width: 155px;
  padding-left: 14px;
  border-left: none;
  margin-top: 5px;
  font-size: 12px;
  font-family: Arial, Helvetica, sans-serif;
}
.a-wrap .msg h3 {
  color: #000;
}
.a-wrap .msg h3 .i {
  font-size: 14px;
  color: #e11010;
}
.a-wrap .msg span {
  display: block;
  color: #444;
  width: 160px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
</style>