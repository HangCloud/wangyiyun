<template>
  <div class="anchor-list">
      <div class="header">
      <span>热门主播</span>
    </div>
    <div v-for="item in AnchorList" :key="item.id">
      <Anchor :AnchorData="item" />
    </div>
  </div>
</template>

<script>
import Anchor from "./Anchor.vue";

export default {
  data() {
    return {
      AnchorList: [
        {
          id: 1,
          imgUrl:
            "http://p2.music.126.net/H3QxWdf0eUiwmhJvA4vrMQ==/1407374893913311.jpg?param=40y40",
          name: "陈立",
          describe: "心理学家、美食家陈立教授"
        },
        {
          id: 2,
          imgUrl:
            "http://p2.music.126.net/H3QxWdf0eUiwmhJvA4vrMQ==/1407374893913311.jpg?param=40y40",
          name: "陈立",
          describe: "心理学家、美食家陈立教授"
        },
        {
          id: 3,
          imgUrl:
            "http://p2.music.126.net/H3QxWdf0eUiwmhJvA4vrMQ==/1407374893913311.jpg?param=40y40",
          name: "陈立",
          describe: "心理学家、美食家陈立教授心理学家、美食家陈立教授"
        },
        {
          id: 4,
          imgUrl:
            "http://p2.music.126.net/H3QxWdf0eUiwmhJvA4vrMQ==/1407374893913311.jpg?param=40y40",
          name: "陈立",
          describe: "心理学家、美食家陈立教授"
        },
        {
          id: 5,
          imgUrl:
            "http://p2.music.126.net/H3QxWdf0eUiwmhJvA4vrMQ==/1407374893913311.jpg?param=40y40",
          name: "陈立",
          describe: "心理学家、美食家陈立教授"
        }
      ]
    };
  },
  components: {
    Anchor
  }
};
</script>

<style scoped>
.anchor-list {
  margin: 18px 0 14px 20px;
}
.anchor-list .header {
  width: 210px;
  height: 24px;
  border-bottom: 1px solid #ccc;
}
.anchor-list .header span {
  float: left;
  font-size: 12px;
  font-family: Arial, Helvetica, sans-serif;
}
</style>