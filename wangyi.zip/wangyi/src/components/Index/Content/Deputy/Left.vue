<template>
  <div class="m-left">
    <min-login />
    <in-singer-list />
    <anchor-list />
  </div>
</template>

<script>
import MinLogin from "./MinLogin.vue";
import InSingerList from "./InSingerList.vue";
import AnchorList from "./AnchorList.vue";

export default {
  components: {
    MinLogin,
    InSingerList,
    AnchorList
  }
};
</script>

<style scoped>
.m-left {
  width: 250px;
  height: 100%;
  position: absolute;
  right: 0;
  border-left:0.5px solid #ccc;
  border-right:0.5px solid #ccc;
}
</style>