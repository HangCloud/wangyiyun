<template>
  <div class="l-wrop">
    <p>登录网易云音乐，可以享受无限收藏的乐趣，并且无限同步到手机</p>
    <a href="#">用户登录</a>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.l-wrop {
  width: 250px;
  height: 126px;
  background: linear-gradient(#fdfdfd, #e2e2e2); /* 渐变背景标准的语法 */
  box-shadow: 0px 2px 5px -3px #333;
}
.l-wrop p {
  width: 205px;
  margin: 0 auto;
  padding: 16px 0;
  line-height: 22px;
  color: #666;
}
.l-wrop a {
  display: block;
  width: 100px;
  height: 31px;
  line-height: 31px;
  text-align: center;
  color: rgb(255, 255, 255);
  background: linear-gradient(#ed212a, #cf070e); 
  border-radius: 3px;
  border:1px solid #9b0409;
  margin: 0px auto;
}
</style>