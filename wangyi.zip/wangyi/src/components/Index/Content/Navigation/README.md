

【MusicList.vue】
是首页的八个歌曲分布的组件

【Navigation.vue】
是首页的几个模块上面的导航组件