<template>
  <div class="nav-type">
    <img src="../../../../assets/Imgs/tag.jpg" alt />
    <a href="#" class="title">{{ recommendeds.title }}</a>
    <div class="tab">
      <a class="type" :href="item.url" v-for="item in recommendeds.navList" :key="item.id">
        <span class="text">{{ item.name }}</span>
        <span class="line">|</span>
      </a>
    </div>
    <span class="more">
      <a href="#">更多</a>
      <i class="iconfont icon-youjiantou1"></i>
    </span>
  </div>
</template>

<script>
export default {
  props: ["recommendeds"]
};
</script>

<style>
a {
  text-decoration: none;
  color: #666;
}

.nav-type {
  width: 690px;
  height: 35px;
  /* background-color: aqua; */
  border-bottom: 2px solid #c20c0c;
}
.nav-type img {
  float: left;
  width: 16px;
  height: 16px;
  padding-top: 10px;
}
.nav-type .title {
  float: left;
  font-size: 20px;
  font-weight: normal;
  line-height: 38px;
  color: #000;
  padding-left: 9px;
  font-family: "Microsoft Yahei", Arial, Helvetica, sans-serif;
}
.nav-type .tab {
  float: left;
  margin: 13px 0 0 15px;
}
.nav-type .tab .type .line{
    margin: 0 8px 0 -2px;
    color:#ccc;
}
.nav-type .tab .type .text {
  padding-left: 5px;
}
.nav-type .tab .type span:hover {
  /* border-bottom: 1px solid #333; */
  text-decoration: underline;
}
.nav-type .tab .type:last-child .line {
  display: none;
}
.nav-type .more {
  float: right;
  line-height: 40px;
}
.nav-type .more .iconfont {
  color: #c20c0c;
  margin-left: -5px;
}
</style>