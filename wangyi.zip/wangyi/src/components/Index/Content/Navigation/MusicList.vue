<template>
  <div class="gq-lb">
    <ul>
      <li v-for="item in musicList" :key="item.id">
        <div class="musicMsg">
          <div class="ranking">
              <i class="iconfont icon-ermai"></i>
              <span>{{ item.number }}</span>
              <i class="iconfont icon-bofang1 play"></i>
          </div>
          <img :src="item.imgUrl" alt />
          <p>
            <img src="../../../../assets/Imgs/dj.jpg" v-if="item.dj" alt />
            <a :href="item.url">{{ item.msg }}</a>
          </p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["musicList"]
};
</script>
<style scoped>
.gq-lb {
  padding: 20px 0px 40px 0px;
  margin-right: 220px;
}
ul li {
  width: 160px;
  height: 204px;
  float: left;
  padding-left: 20px;
  padding-bottom: 30px;
}
ul li .musicMsg {
  width: 140px;
  position: relative;
}

ul li .musicMsg .ranking {
  width: 100%;
  height: 27px;
  top:113px;
  position: absolute;
  background-color: #333;
  opacity: 0.7;
}
ul li .musicMsg .ranking i{
    color: #ccc;
    line-height: 27px;
    padding-left: 10px;
}
ul li .musicMsg .ranking .play{
    margin-left: 38px;
}
ul li .musicMsg .ranking .play:hover{
    cursor: pointer;
    color:#fff;
}
ul li .musicMsg .ranking span{
    color:#fff;
    font-size:13px;
}
ul li .musicMsg p {
  font-size: 14px;
  padding-top: 10px;
  padding-bottom: 10px;
}
ul li .musicMsg p a{
    line-height: 1.5em;
}
ul li .musicMsg p a:hover {
  border-bottom: 1px solid #333;
}
</style>