<template>
  <div class="footer">
    <div class="container">
      <div class="wrap">
        <p class="link">
          <a class="li" v-for="item in policyList" :href="item.url" :key="item.id">
            {{ item.msg }}
            <span class="line li">|</span>
          </a>
        </p>
        <p class="copyright">
          <span class="span">网易公司版权所有©1997-2019</span>
          <span class="span">杭州乐读科技有限公司运营：</span>
          <a
            href="https://p1.music.126.net/Mos9LTpl6kYt6YTutA6gjg==/109951164248627501.png"
            target="_blank"
            class="alink"
          >浙网文[2018]3506-263号</a>
        </p>
        <p class="report">
          <span class="span">违法和不良信息举报电话：0571-89853516</span>
          <span class="span">举报邮箱：</span>
          <a class="alink" href="mailto:ncm5990@163.com">ncm5990@163.com</a>
        </p>
      </div>
      <ul>
        <li v-for="item in unitList" :key="item.id">
            <a :href="item.url" 
            :style="item.style" 
            class="a-link"></a>
            <span class="link-m">{{ item.msg }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
        back:"url("+require("@/assets/Imgs/foot.png")+")",
      policyList: [
        { id: 101, msg: "服务条款", url: "baidu.com" },
        { id: 102, msg: "隐私政策", url: "baidu.com" },
        { id: 103, msg: "儿童隐私政策", url: "baidu.com" },
        { id: 104, msg: "版权投诉指引", url: "baidu.com" },
        { id: 105, msg: "意见反馈", url: "baidu.com" }
      ],
      unitList:[
          {id:1001,msg:"用户认证",style:{
              backgroundImage:"url("+require("@/assets/Imgs/foot.png")+")",
              backgroundPosition: "0px -101px"
          },url:"baidu.com"},
          {id:1002,msg:"独立音乐人",style:{
              backgroundImage:"url("+require("@/assets/Imgs/foot.png")+")",
              backgroundPosition: "0px 0px"
          },url:"baidu.com"},
          {id:1003,msg:"赞赏",style:{
              backgroundImage:"url("+require("@/assets/Imgs/foot.png")+")",
              backgroundPosition: "-62px -50px"
          },url:"baidu.com"},
          {id:1004,msg:"视频奖励",style:{
              backgroundImage:"url("+require("@/assets/Imgs/foot.png")+")",
              backgroundPosition: "0px -101px"
          },url:"baidu.com"},
      ]
    };
  }
};
</script>

<style>
.footer {
  width: 100%;
  height: 150px;
  background-color: #eee;
  box-sizing: border-box;
  border-top: 1px solid #ccc;
}
.footer .container {
  width: 980px;
  height: 90px;
  margin: 0 auto;
  background-color: transparent;
  border: none;
}
.footer .container .wrap {
  font-size: 12px;
  padding-top: 15px;
  width:520px;
  float: left;
}
.footer .container .wrap p{
    height: 24px;
}
.footer .container .wrap .link .li {
  color: #999;
  text-decoration: none;
}
.footer .container ul li .a-link{
    background-size: 110px 450px;
    display: block;
}
.footer .container ul li .link-m{
    color: #999;
    width: 60px;
    text-align: center;
    display: inline-block;
    margin-left: -4px;
}
.footer .container .wrap .copyright,.report {
  color: #666;
}

.footer .container ul{
    float: right;
    width: 360px;
    height: 70px;
    padding-top: 15px;
    margin: 0px;
    right: 0px;
}
.footer .container ul li{
    height: 70px;
    width: 60px;
    margin-left:30px;
    float: right;
}
.footer .container ul li a{
    width:48px;
    height: 48px;
}
</style>