<template>
  <div class="song-h">
    <span>全部</span>
    <button class="choose">
      选择分类
      <i></i>
    </button>
    <button class="hot">热门</button>
    <div class="down-nav">导航模块</div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.song-h {
  padding-top: 30px;
  margin: 0 40px;
  height: 40px;
  border-bottom: 2px solid #c20c0c;
  span {
    font-family: "Microsoft Yahei", Arial, Helvetica, sans-serif;
    font-size: 24px;
  }
  button {
    border: none;
    background-color: transparent;
  }
  .down-nav {
    display: none;
  }
  .choose {
    width: 86px;
    height: 30px;
    box-sizing: border-box;
    border: 0.5px solid #c3c3c3;
    background: linear-gradient(#ffffff, #f1f1f1);
    color: #0c73c2;
    border-radius: 5px;
  }
  .hot {
    float: right;
    width: 46px;
    height: 29px;
    border-radius: 3px;
    background: linear-gradient(#d20c0d, #a80909);
    border: #850202;
    color: #fff;
  }
}
</style>