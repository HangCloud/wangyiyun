
Song     首屏-》歌单页

Index.vue      Song文件夹的入口文件：包括头部菜单搜索导航和歌曲方块列表
OneSong.vue     单个歌曲组件
SongHeader.vue   头部导航组件
SongList.vue     全部歌曲列表