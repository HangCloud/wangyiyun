<template>
    <div class="song-wrap">
        <song-header />
        <song-list />
        </div>    
</template>

<script>
import SongList from './SongList.vue';
import SongHeader from './SongHeader.vue';

export default {
    components:{
        SongList,
        SongHeader,
    }
}
</script>

<style lang="scss" scoped>
    .song-wrap{
        width:980px;
        box-sizing: border-box;
        margin: 0 auto;
        background-color:#fff;
    }
</style>