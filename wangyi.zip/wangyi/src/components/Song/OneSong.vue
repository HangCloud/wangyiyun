<template>
  <div class="gq-lb">
    <ul>
      <li v-for="item in musicList" :key="item.id">
        <div class="musicMsg">
          <div class="ranking">
            <i class="iconfont icon-ermai"></i>
            <span>{{ item.number }}</span>
            <i class="iconfont icon-bofang1 play"></i>
          </div>
          <img :src="item.imgUrl" alt />
          <h5 class="describe">{{ item.songName }}</h5>
          <h5>{{ item.author }}</h5>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["musicList"]
};
</script>
<style scoped>
.gq-lb {
  padding: 20px 0px 40px 0px;
}
ul li {
  width: 150px;
  height: 175px;
  padding-left: 40px;
  padding-bottom: 20px;
  display: inline-block;
}
ul li .musicMsg {
  width: 140px;
  position: relative;
}

ul li .musicMsg .ranking {
  width: 100%;
  height: 27px;
  top: 113px;
  position: absolute;
  background-color: #333;
  opacity: 0.7;
}
ul li .musicMsg .ranking i {
  color: #ccc;
  line-height: 27px;
  padding-left: 10px;
}
ul li .musicMsg .ranking .play {
  margin-left: 38px;
}
ul li .musicMsg .ranking .play:hover {
  cursor: pointer;
  color: #fff;
}
ul li .musicMsg .ranking span {
  color: #fff;
  font-size: 13px;
}

ul li .musicMsg .describe {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 14px;
  font-family: Arial, Helvetica, sans-serif;
}
</style>