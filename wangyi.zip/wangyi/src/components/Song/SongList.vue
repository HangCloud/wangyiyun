<template>
    <div class="song-list">
        <one-song :musicList="dataList" />
    </div>

</template>

<script>
import OneSong from "./OneSong.vue";

export default {
    data(){
        return{
            dataList:[
                {id:1001,number:1234,author:'少年的半岛铁盒',songName:'时光之旅|致你我年少时的回忆',imgUrl:'http://p2.music.126.net/UX78eEDic19VjIwf2e_MGw==/109951164491173755.jpg?param=140y140',identify:'l'},
                {id:1002,number:1234,author:'少年的半岛铁盒',songName:'时光之旅|致你我年少时的回忆',imgUrl:'http://p2.music.126.net/UX78eEDic19VjIwf2e_MGw==/109951164491173755.jpg?param=140y140',identify:'l'},
                {id:1003,number:1234,author:'少年的半岛铁盒',songName:'时光之旅|致你我年少时的回忆',imgUrl:'http://p2.music.126.net/UX78eEDic19VjIwf2e_MGw==/109951164491173755.jpg?param=140y140',identify:'l'},
                {id:1004,number:1234,author:'少年的半岛铁盒',songName:'时光之旅|致你我年少时的回忆',imgUrl:'http://p2.music.126.net/UX78eEDic19VjIwf2e_MGw==/109951164491173755.jpg?param=140y140',identify:'l'},
                {id:1005,number:1234,author:'少年的半岛铁盒',songName:'时光之旅|致你我年少时的回忆',imgUrl:'http://p2.music.126.net/UX78eEDic19VjIwf2e_MGw==/109951164491173755.jpg?param=140y140',identify:'l'},
                {id:1006,number:1234,author:'少年的半岛铁盒',songName:'时光之旅|致你我年少时的回忆',imgUrl:'http://p2.music.126.net/UX78eEDic19VjIwf2e_MGw==/109951164491173755.jpg?param=140y140',identify:'l'},

            ]
        }
    },
    components:{
        OneSong
    }    
}
</script>

<style lang="scss" scoped>

</style>