<template>
  <div class="go-top" v-if="isShow">
    <a href="#">
      <i class="iconfont icon-xiangshangjiantouarrowup"></i>
      <span>TOP</span>
    </a>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isShow: false
    };
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true);
  },
  methods: {
    handleScroll(e) {
      var scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop;
      //    如果滚动条滚动了大于800像素
      if (scrollTop > 100) {
        this.isShow = true;
      } else {
        this.isShow = false;
      }
    }
  }
};
</script>

<style scoped>
.go-top {
  width: 50px;
  height: 45px;
  border: 0.5px solid #ccc;
  position: fixed;
  bottom: 160px;
  right: 117px;
  border-radius: 5px;
  box-sizing: border-box;
  
}
.go-top:hover {
  cursor: pointer;
  background-color: rgba(206, 202, 202,0.2);
}
.go-top a{
  text-decoration: none;
}
.go-top i {
  text-align: center;
  width: 50px;
  height: 25px;
  display: block;
  color: #999;
}
.go-top span {
  width: 50px;
  height: 20px;
  text-align: center;
  display: block;
  color: #666;
}
</style>