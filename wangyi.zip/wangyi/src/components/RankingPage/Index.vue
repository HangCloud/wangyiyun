<template>
  <div class="ranking-page">
    <div class="wrap clearfix">
      <div class="m-ranking-left">
        <ranking-list />
      </div><div class="ranking-right">
        <ranking-right />
      </div>
      <!-- <div class="clear"></div> -->
    </div>
  </div>
</template>

<script>
import RankingList from "./RankingList.vue";
import RankingRight from "./RankingRight.vue";

export default {
  components: {
    RankingList,
    RankingRight
  }
};
</script>

<style scoped>
.ranking-page .wrap {
  width: 980px;
  margin: 0 auto;
  background-color: #fff;
  display: flex;
}
/* 用于清除子元素浮动后父元素高度为0问题 */
.ranking-page .clearfix::after {
  content: "";
  display: block;
  height: 0;
  clear: both;
  visibility: hidden;
}
.ranking-page .wrap .m-ranking-left {
  width: 240px;
}
.ranking-page .wrap .ranking-right {
  width: 740px;
}
.clear {
  clear: left;
}
</style>