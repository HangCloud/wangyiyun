<template>
  <div class="ranking">
    <h3>{{ data.title }}</h3>
    <div
      class="ranking-wrap"
      :class="[item.active==true?'active':'']"
      v-for="item in data.dataList"
      :key="item.id"
    >
      <img :src="item.imgUrl" alt />
      <div class="msg">
        <h4 class="title">{{ item.name }}</h4>
        <h4 class="detail">{{ item.detail }}</h4>
      </div>
    </div>
  </div>
  <!-- :class="[active?data.active:'']" -->
</template>

<script>
export default {
  props: ["data"]
};
</script>

<style scoped>
.ranking h3 {
  padding: 20px 10px 12px 15px;
  color: #000;
  font-size: 14px;
  font-weight: bold;
}
.ranking .ranking-wrap {
  width: 240px;
  height: 62px;
}

.ranking .ranking-wrap:hover {
  cursor: pointer;
  background-color: #f4f2f2;
}
.ranking .active {
  background-color: #e6e6e6;
}
.ranking .ranking-wrap img {
  padding: 10px 0 0 15px;
  float: left;
}
.ranking .ranking-wrap .msg {
  width: 180px;
  height: 40px;
  margin-top: 10px;
  float: left;
}
.ranking .ranking-wrap .title {
  padding: 0 0 0 10px;
}
.ranking .ranking-wrap .detail {
  padding: 13px 0 0 10px;
  color: #888;
}
</style>