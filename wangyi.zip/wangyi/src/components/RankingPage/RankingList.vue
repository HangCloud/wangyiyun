<template>
  <div class="ranking-left">
    <ranking-comp :data="RankingList[0]" />
    <ranking-comp :data="RankingList[1]" />
  </div>
</template>

<script>
import RankingComp from "./RankingComp.vue";

export default {
  components: {
    RankingComp
  },
  data() {
    return {
      RankingList: [
        {
          id: 101,
          title: "云音乐排行榜",
          dataList: [
            {
              id: 10101,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "云音乐飙升榜",
              detail: "每天更新",
              active:true
            },
            {
              id: 10102,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "云音乐新歌榜",
              detail: "每天更新",
              active:false
            },
            {
              id: 10103,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "网易原创歌曲榜",
              detail: "每周四更新",
              active:false
            },
            {
              id: 10104,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "云音乐热歌榜",
              detail: "每周四更新",
              active:false
            }
          ]
        },
        {
          id: 102,
          title: "全球媒体榜",
          dataList: [
            {
              id: 10201,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "云音乐飙升榜",
              detail: "每天更新",
              active:false
            },
            {
              id: 10202,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "云音乐新歌榜",
              detail: "每天更新",
              active:false
            },
            {
              id: 10203,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "网易原创歌曲榜",
              detail: "每周四更新",
              active:false
            },
            {
              id: 10204,
              imgUrl:
                "http://p1.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=40y40",
              name: "云音乐热歌榜",
              detail: "每周四更新",
              active:false
            }
          ]
        }
      ]
    };
  }
};
</script>

<style scoped>
.ranking-left {
  width: 240px;
  border-left: 0.5px solid #ccc;
  border-right: 0.5px solid #ccc;
  background-color: #f9f9f9;
  box-sizing: border-box;
  height: 100%;
}
</style>