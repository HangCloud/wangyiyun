<template>
  <div class="wrap">
    <div class="r-left">
      <img :src="data.imgUrl" alt />
    </div>
    <div class="r-right">
      <h3>{{ data.title }}</h3>
      <div class="content">
        <i class="iconfont icon-shijian"></i>
        <span class="new">最近更新：{{ data.date }}</span>
        <span class="frequency">({{ data.detail }})</span>
      </div>
      <div class="operation">
        <a class="plan">
          <i class="iconfont icon-bofang1"></i>
          播放
        </a>
        <a class="add">+</a>
        <a class="love">
          <i class="iconfont icon-wenjiantianjia"></i>
          ({{ data.collection }})
        </a>
        <a class="forwarding">
          <i class="iconfont icon-zhuanfa"></i>
          {{ data.forwarding}}
        </a>
        <a class="down">
          <i class="iconfont icon-xiazai"></i>
          下载
        </a>
        <a class="msg">
          <i class="iconfont icon-liuyan"></i>
          {{ data.comments }}
        </a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["data"]
};
</script>

<style scoped>
.r-left {
  float: left;
}
.r-left img{
    border: 1px solid #ccc;
    box-sizing: border-box;
    padding: 5px;
}
.r-right {
  float: left;
  padding-left: 30px;
  padding-top: 17px;
}
.r-right h3 {
  font-size: 20px;
  font-family: "Microsoft Yahei", Arial, Helvetica, sans-serif;
}
.r-right .content {
  padding: 15px 0px;
}
.r-right .content i {
  font-size: 14px;
}
.r-right .content .new {
  color: #666;
}
.r-right .content .frequency {
  color: #999;
}
.r-right .operation {
  padding: 17px 0;
}
.r-right .operation a {
  text-align: center;
  line-height: 30px;
  float: left;
  margin-left: 5px;
}
.r-right .operation .plan {
  width: 66px;
  height: 30px;
  border: none;
  background: linear-gradient(#4da1e0, #1d6ebe);
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
  color: #fff;
  border-right: 1px solid #ccc;
  margin: 0px;
}
.r-right .operation .add {
  display: inherit;
  width: 20px;
  height: 30px;
  margin-left: 0px;
  background: linear-gradient(#4da1e0, #1d6ebe);
  color: #fff;
  font-weight: bold;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}
.r-right .operation .love,.forwarding,.down,.msg {
  height: 30px;
  background: linear-gradient(#fff, #f1f1f1);
  color: #000;
  border-radius: 4px;
  border: 0.5px solid #bbb;
  padding: 0 7px;
}
</style>