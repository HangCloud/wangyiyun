<template>
  <div class="rl-wrap">
    <div class="rl-header">
      <div class="header-left">
        <h2>歌曲列表</h2>
        <span>{{ data.count }}首歌</span>
      </div>
      <div class="header-right">
        <span>
          播放：
          <span>{{ data.playCount }}</span>
          次
        </span>
      </div>
    </div>

    <div class="rl-list">
      <table>
        <tr>
          <th class="wr1"></th>
          <th class="wr2">标题</th>
          <th class="wr3">时长</th>
          <th class="wr4">歌手</th>
        </tr>
        <tr
          v-for="(item,index) in musicList"
          class="l-tr"
          :key="item.id"
          :class="{'top3':index<3,'edd':index%2==0}"
        >
          <td class="td1">
            <span>{{ index+1 }}</span>
            <div class="state">
              <div class="new" v-if="item.state=='new'">
                <i class="iconfont icon-new"></i>
              </div>
              <div class="up" v-else-if="item.state=='up'">
                <i class="iconfont icon-xiangxiajiantou"></i>
                {{ item.sNumber}}
              </div>
              <div class="down" v-else>
                <i class="iconfont icon-arrow-up"></i>
                {{ item.sNumber}}
              </div>
            </div>
          </td>
          <td class="td2">
            <img :src="item.imgUrl" alt />
            <i class="iconfont icon-bofang1"></i>
            {{ item.name }}
            <h6>{{ item.detail }}</h6>
            <i class="iconfont icon-dianshi mv" v-if="item.mv" title='播放MV'></i>
          </td>
          <td class="td3">
            <div class="a">{{ item.time }}</div>
            <div class="b">
              <i class="iconfont icon-jia" title="添加到播放列表"></i>
              <i class="iconfont icon-wenjiantianjia" title="收藏"></i>
              <i class="iconfont icon-zhuanfa" title="分享"></i>
              <i class="iconfont icon-xiazai" title="下载"></i>
            </div>
          </td>
          <td class="td4">{{ item.author }}</td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  props: ["data", "musicList"]
};
</script>

<style scoped>
</style>
<style lang="scss" scoped>
.rl-wrap {
  .rl-header {
    padding-bottom: 6px;
    border-bottom: 2px solid #c20c0c;
    .header-left {
      display: inline-block;
      h2 {
        display: inline-block;
        font-family: "Microsoft Yahei", Arial, Helvetica, sans-serif;
        font-size: 20px;
      }
      span {
        font-family: "Microsoft Yahei", Arial, Helvetica, sans-serif;
        font-size: 12px;
        padding-left: 9px;
      }
    }
    .header-right {
      float: right;
      margin-top: 10px;
      span {
        span {
          color: #c20c0c;
          font-weight: bold;
        }
      }
    }
  }
  .rl-list {
    table {
      border-collapse: collapse;
      border-spacing: 0;
      table-layout: fixed;
      border: 1px solid #d9d9d9;
      .l-tr {
        height: 30px;
        &:hover .td3 .a {
          display: none;
        }
        &:hover .td3 .b {
          display: inline-block;
        }
      }
      tr {
        th {
          text-align: left;
          height: 34px;
          background: linear-gradient(#fff, #f0f0f0);
          font-weight: normal;
          color: #666;
        }
        .wr1,
        .td1 {
          width: 88px;
        }
        .wr2,
        .td2 {
          width: 500px;
        }
        .wr3,
        .td3 {
          width: 120px;
        }
        .wr4,
        .td4 {
          width: 26%;
        }
        .wr2,
        .wr3,
        .wr4 {
          border-left: 0.5px solid #ccc;
          padding-left: 10px;
        }
        td {
          padding-left: 10px;
          span {
            float: left;
          }
          .state {
            float: right;
            padding-right: 10px;
            .new {
              color: #268330;
            }
            .up {
              font-size: 12px;
              color: #c20c0c;
              i {
                font-size: 10px;
                margin-right: -5px;
              }
            }
            .down {
              font-size: 12px;
              color: #c20c0c;
              i {
                font-size: 10px;
                color: #4ab8ea;
                margin-right: -5px;
              }
            }
          }
        }
        .td1 {
          text-align: center;
        }
        .td2 {
          img {
            width: 50px;
            height: 50px;
            padding: 10px;
          }
          i {
            color: #b3b3b3;
            &:hover {
              color: #666;
              cursor: pointer;
            }
          }
          h6 {
            display: inline;
            color: #999;
          }
          .mv {
            color: #c20c0c;
            border: 1px solid #ccc;
            &:hover{
                color: #c20c0c;
                cursor: pointer;
            }
          }
        }
        .td3 {
          .b {
            i {
              font-size: 13px;
              font-weight: bold;
              color: #888;
              &:hover {
                cursor: pointer;
                color: #444;
              }
            }
            display: none;
          }
        }
      }
      .top3 {
        height: 70px;
        .td2 {
          line-height: 70px;
        }
      }
      .edd {
        background-color: #f7f7f7;
      }
    }
  }
}
</style>