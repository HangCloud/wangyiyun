<template>
  <div class="right-wrap">
    <div class="rw-header">
      <right-header :data="headerData" />
    </div>
    <div class="rw-list">
      <right-list :data="overView" :musicList="musicList"/>
    </div>
    <div class="appraise">
        <ranking-appraise :number="appNumber" :dataList="appList" />
    </div>
  </div>
</template>

<script>
import RightHeader from "./RightHeader.vue";
import RightList from "./RightList.vue";
import RankingAppraise from "./RankingAppraise.vue";

export default {
  data() {
    return {
      headerData: {
        imgUrl:
          "http://p2.music.126.net/DrRIg6CrgDfVLEph9SNh7w==/18696095720518497.jpg?param=150y150",
        title: "云音乐飙升榜",
        date: "11月18日",
        detail: "每日更新",
        collection: 2504559, //收藏量
        forwarding: 7216, //转发量
        comments: 159170 //评论量
      },
      overView:{count:100,playCount:6899329},
      musicList:[
          {id:101,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'http://p2.music.126.net/2pF-tKT79yQLWfOnm49-hA==/109951164496579083.jpg?param=50y50&quality=100',mv:true},
          {id:102,state:'up',sNumber:333,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'http://p2.music.126.net/2pF-tKT79yQLWfOnm49-hA==/109951164496579083.jpg?param=50y50&quality=100',mv:false},
          {id:103,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'',imgUrl:'http://p2.music.126.net/2pF-tKT79yQLWfOnm49-hA==/109951164496579083.jpg?param=50y50&quality=100',mv:true},
          {id:104,state:'down',sNumber:12,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false},
          {id:105,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false},
          {id:106,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false},
          {id:107,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false},
          {id:108,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false},
          {id:109,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false},
          {id:110,state:'new',sNumber:0,name:'忘情水',time:'03:32',author:'刘德华',detail:'一首好歌',imgUrl:'',mv:false}
      ],
      appNumber:32767,
      appList:[
          {id:1001,imgUrl:'https://p1.music.126.net/3WmdV4ECGurfrZgDqLeDGQ==/109951164497811094.jpg?param=50y50',name:'咋还不下课鸭',content:'：IU的音乐真的不是靠粉丝夸出来的，首首精良，十一月有你，我的耳朵很幸福',time:'08:49',praise:123,rank:''},
           {id:1002,imgUrl:'https://p1.music.126.net/J_-pnML0bVzfHI5s9YzYOw==/109951164497653504.jpg?param=50y50',name:'没思春期版权这会员不香了',content:'：我天前三iu霸榜没点进来还以为我还在来还以为我还在来还以为我还在来还以为我还在iu的歌单里',time:'09:05',praise:55,rank:'vip'},
            {id:1003,imgUrl:'https://p1.music.126.net/eUNDb2_fwQnW4YhMFeqpxw==/109951164421196743.jpg?param=50y50',name:'木槿昔年minor',content:'：这个女人过分的优秀[多多比耶][多多大笑][多多亲吻][多多调皮]',time:'08:31',praise:76,rank:'yvip'},
             {id:1004,imgUrl:'https://p1.music.126.net/eUNDb2_fwQnW4YhMFeqpxw==/109951164421196743.jpg?param=50y50',name:'木槿昔年minor',content:'：这个女人过分的优秀[多多比耶][多多大笑][多多亲吻][多多调皮]',time:'08:31',praise:76,rank:'yvip'},
      ]
    };
  },
  components: {
    RightHeader,
    RightList,
    RankingAppraise
  }
};
</script>

<style scoped>
.right-wrap {
  width: 740px;
  box-sizing: border-box;
  padding: 40px;
}
.right-wrap .rw-header{
    height: 210px;
}
</style>