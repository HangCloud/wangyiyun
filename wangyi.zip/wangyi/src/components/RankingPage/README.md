

Index.vue：启动页

RankingList.vue：左侧排行榜
RankingComp.vue：左侧榜单组件

RankingRight.vue：右侧主要明细部分
RightHeader.vue：右侧头部部分
RightList.vue：右侧列表部分
RankingAppraise.vue：右侧评论区