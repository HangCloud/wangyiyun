<template>
  <div class="app-wrap">
    <div class="header">
      <span class="pl">评论</span>
      <span class="pl-no">共{{ number }}条评论</span>
    </div>
    <div class="appraise">
      <img src="http://s4.music.126.net/style/web2/img/default/default_avatar.jpg?param=50y50" alt />
      <div class="ap-text">
        <textarea name="text" id cols="30" rows="10" placeholder="评论"></textarea>
        <div class="phlz">
          <i class="iconfont icon-xiaolian xl"></i>
          <i class="iconfont icon-at"></i>
        </div>
        <div class="send">
          <span>{{ surplus }}</span>
          <button class="sendBtn">评论</button>
        </div>
      </div>
    </div>
    <div class="msg-list">
      <p class="list-header">精彩评论</p>
      <div class="msg" v-for="item in dataList" :key="item.id">
        <div class="m-left">
          <img :src="item.imgUrl" alt />
        </div>
        <div class="m-right">
          <p class="m-hd">
            <span class="rank-name">
              <a href="#">{{ item.name }}</a>
              <img src="../../assets/Imgs/vip.png" alt v-if="item.rank=='vip'" />
              <img src="../../assets/Imgs/svip.png" alt v-else-if="item.rank=='yvip'" class="yvip" />
            </span>
            <span>{{ item.content }}</span>
          </p>
          <p class="m-bt">
            <span class="time">{{ item.time }}</span>
            <span class="zan">
              <span>
                <i class="iconfont icon-zan"></i>
                ({{ item.praise }}) |
              </span>
              <span class="reply">回复</span>
            </span>
          </p>
        </div>
      </div>
    </div>
    <div class="page">
      <span>&lt;上一页</span>
      <el-pagination :background="false" layout="pager" :total="1000" :pager-count="9"></el-pagination>
      <span>下一页&gt;</span>
    </div>
  </div>
</template>

<script>
export default {
  props: ["number", "dataList"],
  data() {
    return {
      surplus: 140
    };
  }
};
</script>

<style lang="scss" scoped>
.app-wrap {
  .header {
    padding-bottom: 6px;
    border-bottom: 2px solid #c20c0c;
    padding-top: 40px;
    .pl {
      font-size: 20px;
      font-family: "Microsoft Yahei", Arial, Helvetica, sans-serif;
    }
    .pl-no {
      padding-left: 10px;
      color: #666;
      font-size: 13px;
    }
  }
  .appraise {
    padding-top: 20px;
    img {
      width: 50px;
    }
    .ap-text {
      width: 90%;
      height: 63px;
      display: inline-block;
      position: relative;
      padding-left: 5px;
      &::after,
      &::before {
        content: "";
        display: block;
        position: absolute;
        width: 0;
        height: 0;
        border: 6px solid transparent;
        border-right-color: white;
        left: -5px;
        top: 8px;
        z-index: 1;
      }
      &::after {
        left: -6px;
        border-right-color: #cdcdcd;
        z-index: 0;
      }
      textarea {
        width: 100%;
        height: 63px;
        resize: none;
        padding: 5px;
        border-color: #cdcdcd;
        box-sizing: border-box;
        position: relative;
      }
      .phlz {
        display: inline-block;
        padding-top:5px;
        i {
          font-size: 20px;
          color: #929292;
          &:hover {
            cursor: pointer;
          }
        }
        .xl {
          font-size: 22px;
        }
      }
      .send {
        color: #999;
        float: right;
        padding-top:5px;
        .sendBtn {
          color: #fff;
          background: linear-gradient(#4da1e0, #0e65bc);
          border: 1px solid #4da1e0;
          border-radius: 3px;
        }
      }
    }
  }
  .msg-list {
    .list-header {
      border-bottom: 1px solid #cdcdcd;
      color: #cdcdcd;
      padding: 10px 0;
    }
    .msg {
      padding-top: 15px;
      min-height: 70px;
      border-bottom: 1px dotted #ccc;
      .m-left {
        float: left;
        width: 50px;
        height: 50px;
      }
      .m-right {
        padding-left: 10px;
        float: left;
        width: 600px;
        .m-hd {
          min-height: 27px;
        }
        p {
          .rank-name {
            a {
              text-decoration: none;
              color: #0e65bc;
              &:hover {
                text-decoration: underline;
              }
            }
            img {
              width: 25px;
            }
            .yvip {
              height: 13px;
              width: 30px;
            }
          }
          span {
            i {
              color: #1175bb;
            }
          }
          .zan {
            float: right;
            span {
              color: #666;
            }
            .reply {
              &:hover {
                cursor: pointer;
                text-decoration: underline;
              }
            }
          }
        }
        .m-bt {
          padding-top: 10px;
        }
      }
    }
  }
  .page {
    text-align: center;
    span {
      display: inline-block;
      width: 71px;
      height: 26px;
      line-height: 26px;
      text-align: center;
      background: linear-gradient(#fcfcfc, #cccccc);
      border: 1px solid #ccc;
      border-radius: 3px;
      color:#bbb;
      cursor: pointer;
    }
    .el-pagination {
      display: inline-block;
      line-height: 25px;
      padding: 0;
    }
  }
}
.app-wrap .msg-list .msg:last-child {
  border-bottom: none;
}
/deep/.page .el-pagination ul li:first-child{
  margin: 0px;
}
/deep/.page .el-pagination ul li.active {
  background: linear-gradient(#ed1f29, #a2161b);
  color: #fff;
}
/deep/.page .el-pagination ul li {
  border: 1px solid #ccc;
  line-height: 24px;
  min-width: 25px;
  height: 24px;
  margin-left: 3px;
  border-radius: 3px;
  font-family: Arial, Helvetica, sans-serif;
  font-weight: 500;
}
</style>