import axios from '@/axios.js'

let api = {
    //首页导航
    getNavList() {
        return axios.get("/Main/getNavList");
    },
    // 首页大轮播图列表
    getSlideshowList(){
        return axios.get("/Main/getSlideshowList")
    }
}
export default api;